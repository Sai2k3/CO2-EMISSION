# Unearthing-the-Environmental-Impact-of-Human-Activity-Global-CO2-Emission-Analysis

dashboard public link:https://public.tableau.com/views/CO2DemoDash/Dashboard1?:language=en-GB&publish=yes&:display_count=n&:origin=viz_share_link

story public link:https://public.tableau.com/views/CO2Demostory/CO2EmissionStory?:language=en-GB&publish=yes&:display_count=n&:origin=viz_share_link

project demonstration video link:https://drive.google.com/file/d/1l2ybA1lD12wYqZDPPdvkpk-TXVgJHuuC/view?usp=share_link
